import { useEffect, useState } from "react";

const DISCORD_BLURPLE = "#5865F2";

function StatusDot({ online }: { online: boolean }) {
  return (
    <span
      className="inline-block rounded-full"
      style={{
        width: 10,
        height: 10,
        background: online ? "#57F287" : "#ED4245",
        boxShadow: online ? "0 0 6px #57F287" : "0 0 6px #ED4245",
      }}
    />
  );
}

function StatCard({
  label,
  value,
  sub,
  icon,
  accent,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: string;
  accent: string;
}) {
  return (
    <div
      className="rounded-2xl p-5 flex flex-col gap-2"
      style={{ background: "#2B2D31" }}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#B5BAC1" }}>
          {label}
        </span>
        <span
          className="text-xl rounded-lg px-2 py-1"
          style={{ background: accent + "22" }}
        >
          {icon}
        </span>
      </div>
      <span className="text-3xl font-bold" style={{ color: "#F2F3F5" }}>
        {value}
      </span>
      {sub && (
        <span className="text-xs" style={{ color: "#B5BAC1" }}>
          {sub}
        </span>
      )}
    </div>
  );
}

function useUptime(start: number) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.floor((now - start) / 1000);
  const h = Math.floor(diff / 3600);
  const m = Math.floor((diff % 3600) / 60);
  const s = diff % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

const MOCK_SERVERS = [
  { name: "Just A Dev Hub", id: "1099123456780001", members: 312 },
  { name: "Malay Coders", id: "1099123456780002", members: 87 },
  { name: "Bot Testing Ground", id: "1099123456780003", members: 14 },
  { name: "My Private Server", id: "1099123456780004", members: 6 },
];

const MOCK_LOGS = [
  { time: "10:46:54", event: "Bot connected to Gateway", type: "success" },
  { time: "10:46:54", event: "Slash commands synced (3 commands)", type: "info" },
  { time: "10:47:01", event: "/speak used in #general → Just A Dev Hub", type: "command" },
  { time: "10:47:33", event: "/servers used", type: "command" },
  { time: "10:48:12", event: "Heartbeat ACK (latency: 42ms)", type: "info" },
  { time: "10:49:05", event: "/speak used in #announcements → Malay Coders", type: "command" },
  { time: "10:50:18", event: "Heartbeat ACK (latency: 38ms)", type: "info" },
];

const startTime = Date.now() - 5 * 60 * 1000 - 23 * 1000;

export function Dashboard() {
  const uptime = useUptime(startTime);
  const [latency] = useState(42);

  return (
    <div
      className="min-h-screen font-sans"
      style={{
        background: "#1E1F22",
        color: "#F2F3F5",
        fontFamily: "'Inter', 'Segoe UI', sans-serif",
      }}
    >
      {/* Sidebar */}
      <div className="flex min-h-screen">
        <aside
          className="flex flex-col gap-1 py-6 px-3"
          style={{ width: 220, background: "#2B2D31", borderRight: "1px solid #1E1F22" }}
        >
          {/* Bot Avatar */}
          <div className="flex items-center gap-3 px-3 mb-6">
            <div
              className="relative flex items-center justify-center rounded-full text-2xl"
              style={{ width: 42, height: 42, background: DISCORD_BLURPLE }}
            >
              🤖
              <span
                className="absolute bottom-0 right-0 rounded-full border-2"
                style={{
                  width: 13,
                  height: 13,
                  background: "#57F287",
                  borderColor: "#2B2D31",
                }}
              />
            </div>
            <div>
              <div className="font-bold text-sm" style={{ color: "#F2F3F5" }}>
                Just A Bot
              </div>
              <div className="text-xs flex items-center gap-1" style={{ color: "#57F287" }}>
                <StatusDot online={true} /> Online
              </div>
            </div>
          </div>

          {[
            { icon: "📊", label: "Overview", active: true },
            { icon: "🖥️", label: "Servers", active: false },
            { icon: "📋", label: "Logs", active: false },
            { icon: "⚙️", label: "Settings", active: false },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium cursor-pointer"
              style={{
                background: item.active ? DISCORD_BLURPLE + "33" : "transparent",
                color: item.active ? "#fff" : "#B5BAC1",
              }}
            >
              <span>{item.icon}</span>
              {item.label}
            </div>
          ))}
        </aside>

        {/* Main */}
        <main className="flex-1 p-8 overflow-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-bold" style={{ color: "#F2F3F5" }}>
                Bot Overview
              </h1>
              <p className="text-sm mt-1" style={{ color: "#B5BAC1" }}>
                Real-time stats for Just A Bot
              </p>
            </div>
            <div
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold"
              style={{ background: "#57F28722", color: "#57F287", border: "1px solid #57F28744" }}
            >
              <StatusDot online={true} />
              Connected
            </div>
          </div>

          {/* Stat Cards */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <StatCard label="Uptime" value={uptime} sub="Since last restart" icon="⏱️" accent="#57F287" />
            <StatCard label="Servers" value={MOCK_SERVERS.length} sub="Active guilds" icon="🖥️" accent={DISCORD_BLURPLE} />
            <StatCard label="Latency" value={`${latency}ms`} sub="Gateway ping" icon="📡" accent="#FEE75C" />
            <StatCard label="Commands" value={3} sub="/speak /leaveserver /servers" icon="⚡" accent="#EB459E" />
          </div>

          {/* Lower section */}
          <div className="grid grid-cols-2 gap-6">
            {/* Server List */}
            <div className="rounded-2xl p-5" style={{ background: "#2B2D31" }}>
              <h2 className="font-bold mb-4 text-sm uppercase tracking-widest" style={{ color: "#B5BAC1" }}>
                🖥️ Active Servers
              </h2>
              <div className="flex flex-col gap-2">
                {MOCK_SERVERS.map((s) => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between rounded-xl px-4 py-3"
                    style={{ background: "#1E1F22" }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="rounded-xl flex items-center justify-center text-base font-bold"
                        style={{
                          width: 36,
                          height: 36,
                          background: DISCORD_BLURPLE + "33",
                          color: DISCORD_BLURPLE,
                        }}
                      >
                        {s.name[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-sm" style={{ color: "#F2F3F5" }}>
                          {s.name}
                        </div>
                        <div className="text-xs" style={{ color: "#B5BAC1" }}>
                          {s.id}
                        </div>
                      </div>
                    </div>
                    <span
                      className="text-xs font-semibold px-2 py-1 rounded-full"
                      style={{ background: "#5865F233", color: DISCORD_BLURPLE }}
                    >
                      {s.members} members
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Activity Log */}
            <div className="rounded-2xl p-5" style={{ background: "#2B2D31" }}>
              <h2 className="font-bold mb-4 text-sm uppercase tracking-widest" style={{ color: "#B5BAC1" }}>
                📋 Activity Log
              </h2>
              <div className="flex flex-col gap-2">
                {MOCK_LOGS.map((log, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3 rounded-xl px-4 py-2"
                    style={{ background: "#1E1F22" }}
                  >
                    <span
                      className="text-xs font-mono mt-0.5 shrink-0"
                      style={{ color: "#B5BAC1" }}
                    >
                      {log.time}
                    </span>
                    <span
                      className="text-xs"
                      style={{
                        color:
                          log.type === "success"
                            ? "#57F287"
                            : log.type === "command"
                            ? "#FEE75C"
                            : "#B5BAC1",
                      }}
                    >
                      {log.event}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
