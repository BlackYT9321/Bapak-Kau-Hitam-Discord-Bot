import { Router, type IRouter } from "express";
import {
  GetBotStatsResponse,
  ReportBotStatsBody,
  AppendBotLogBody,
} from "@workspace/api-zod";
import { db, botStatsTable, botServersTable, botLogsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();
const MAX_LOGS = 50;
const OFFLINE_THRESHOLD_MS = 60_000;

router.get("/bot/stats", async (_req, res) => {
  const [stats] = await db.select().from(botStatsTable).where(eq(botStatsTable.id, 1));
  const servers = await db.select().from(botServersTable);
  const logs = await db
    .select()
    .from(botLogsTable)
    .orderBy(desc(botLogsTable.createdAt))
    .limit(MAX_LOGS);

  const online =
    !!stats?.lastHeartbeat &&
    Date.now() - new Date(stats.lastHeartbeat).getTime() < OFFLINE_THRESHOLD_MS;

  const startedAt = stats?.startedAt || null;
  const uptimeSeconds = startedAt
    ? Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000)
    : 0;

  const data = GetBotStatsResponse.parse({
    online,
    botName: stats?.botName ?? "Just A Bot",
    botId: stats?.botId ?? "",
    latency: stats?.latency ?? 0,
    serverCount: stats?.serverCount ?? 0,
    servers: servers.map((s) => ({ id: s.id, name: s.name, memberCount: s.memberCount })),
    startedAt,
    uptimeSeconds,
    logs: logs.map((l) => ({ time: l.time, event: l.event, type: l.type })),
  });
  res.json(data);
});

router.post("/bot/stats", async (req, res) => {
  const body = ReportBotStatsBody.parse(req.body);

  const existing = await db.select({ startedAt: botStatsTable.startedAt }).from(botStatsTable).where(eq(botStatsTable.id, 1));
  const startedAt = existing[0]?.startedAt || body.startedAt;

  await db
    .insert(botStatsTable)
    .values({
      id: 1,
      botName: body.botName,
      botId: body.botId,
      latency: body.latency,
      serverCount: body.serverCount,
      startedAt,
      online: true,
      lastHeartbeat: new Date(),
    })
    .onConflictDoUpdate({
      target: botStatsTable.id,
      set: {
        botName: body.botName,
        botId: body.botId,
        latency: body.latency,
        serverCount: body.serverCount,
        online: true,
        lastHeartbeat: new Date(),
      },
    });

  if (body.servers.length > 0) {
    await db.delete(botServersTable);
    await db.insert(botServersTable).values(
      body.servers.map((s) => ({ id: s.id, name: s.name, memberCount: s.memberCount }))
    );
  }

  res.json({ status: "ok" });
});

router.post("/bot/logs", async (req, res) => {
  const body = AppendBotLogBody.parse(req.body);
  const time = new Date().toISOString();

  await db.insert(botLogsTable).values({ time, event: body.event, type: body.type });

  const allLogs = await db
    .select({ id: botLogsTable.id })
    .from(botLogsTable)
    .orderBy(desc(botLogsTable.createdAt));

  if (allLogs.length > MAX_LOGS) {
    const toDelete = allLogs.slice(MAX_LOGS).map((l) => l.id);
    for (const id of toDelete) {
      await db.delete(botLogsTable).where(eq(botLogsTable.id, id));
    }
  }

  res.json({ status: "ok" });
});

export default router;
