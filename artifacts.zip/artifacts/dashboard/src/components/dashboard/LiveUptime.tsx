import React, { useState, useEffect } from "react";

export function LiveUptime({ uptimeSeconds, startedAt }: { uptimeSeconds: number, startedAt: string | null }) {
  const [currentUptime, setCurrentUptime] = useState(uptimeSeconds);

  useEffect(() => {
    setCurrentUptime(uptimeSeconds);
    const interval = setInterval(() => {
      setCurrentUptime(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [uptimeSeconds]);

  const formatUptime = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24 * 24));
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);

    const pad = (n: number) => n.toString().padStart(2, '0');
    
    if (d > 0) return `${d}d ${pad(h)}h ${pad(m)}m ${pad(s)}s`;
    return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
  };

  return (
    <div className="font-mono tabular-nums text-foreground tracking-tight">
      {formatUptime(currentUptime)}
    </div>
  );
}
