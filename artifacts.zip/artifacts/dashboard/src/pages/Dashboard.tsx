import React from "react";
import { useGetBotStats, getGetBotStatsQueryKey } from "@workspace/api-client-react";
import { LiveUptime } from "@/components/dashboard/LiveUptime";
import { Activity, Server, Clock, Zap, Cpu, TerminalSquare, AlertCircle, CheckCircle2, Info } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading, isError } = useGetBotStats({
    query: {
      refetchInterval: 10000,
      queryKey: getGetBotStatsQueryKey(),
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen w-full bg-background p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-12 w-12 rounded-lg bg-card" />
            <div className="space-y-2">
              <Skeleton className="h-6 w-48 bg-card" />
              <Skeleton className="h-4 w-24 bg-card" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-28 w-full rounded-lg bg-card" />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <Skeleton className="h-8 w-48 bg-card" />
              <Skeleton className="h-[400px] w-full rounded-lg bg-card" />
            </div>
            <div className="space-y-4">
              <Skeleton className="h-8 w-48 bg-card" />
              <Skeleton className="h-[400px] w-full rounded-lg bg-card" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isError || !stats) {
    return (
      <div className="min-h-screen w-full bg-background p-6 flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto" />
          <h2 className="text-xl font-medium text-foreground">Failed to load bot stats</h2>
          <p className="text-muted-foreground">The bot might be offline or the API is unreachable.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-background p-4 md:p-6 lg:p-8 font-sans selection:bg-primary/30">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-xl bg-card border border-card-border flex items-center justify-center shadow-lg">
              <Cpu className="w-7 h-7 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground tracking-tight flex items-center gap-3">
                {stats.botName}
                <Badge variant="outline" className={`px-2 py-0.5 rounded-full border text-xs font-medium uppercase tracking-wider ${stats.online ? "bg-[#23a559]/10 text-[#23a559] border-[#23a559]/20" : "bg-destructive/10 text-destructive border-destructive/20"}`}>
                  {stats.online ? "Online" : "Offline"}
                </Badge>
              </h1>
              <p className="text-sm text-muted-foreground font-mono mt-1 opacity-80">{stats.botId}</p>
            </div>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-5 opacity-20 group-hover:opacity-30 transition-opacity">
              <Activity className="w-12 h-12 text-foreground" />
            </div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Status</p>
            <div className="text-2xl font-semibold text-foreground">
              {stats.online ? "Operational" : "Disconnected"}
            </div>
          </div>
          
          <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-5 opacity-20 group-hover:opacity-30 transition-opacity">
              <Clock className="w-12 h-12 text-primary" />
            </div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Uptime</p>
            <div className="text-2xl font-semibold text-foreground">
              {stats.online ? (
                <LiveUptime uptimeSeconds={stats.uptimeSeconds} startedAt={stats.startedAt} />
              ) : (
                <span className="text-muted-foreground">--</span>
              )}
            </div>
          </div>

          <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-5 opacity-20 group-hover:opacity-30 transition-opacity">
              <Server className="w-12 h-12 text-[#23a559]" />
            </div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Servers</p>
            <div className="text-2xl font-semibold text-foreground font-mono tabular-nums">
              {stats.serverCount.toLocaleString()}
            </div>
          </div>

          <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-5 opacity-20 group-hover:opacity-30 transition-opacity">
              <Zap className="w-12 h-12 text-[#faa61a]" />
            </div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Latency</p>
            <div className="text-2xl font-semibold text-foreground font-mono tabular-nums">
              {stats.latency}<span className="text-base text-muted-foreground ml-1">ms</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Logs */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2 px-1">
              <TerminalSquare className="w-5 h-5 text-muted-foreground" />
              <h2 className="text-lg font-medium text-foreground">Live Activity</h2>
            </div>
            <div className="bg-card border border-card-border rounded-xl shadow-sm overflow-hidden h-[500px] flex flex-col">
              <div className="flex-1 overflow-y-auto p-4 space-y-1 font-mono text-sm">
                {stats.logs.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-muted-foreground">
                    No recent activity
                  </div>
                ) : (
                  stats.logs.map((log, i) => (
                    <div key={i} className="flex items-start gap-3 py-1 hover:bg-white/5 px-2 rounded -mx-2 transition-colors">
                      <span className="text-muted-foreground shrink-0 w-20 opacity-60">
                        {new Date(log.time).toLocaleTimeString(undefined, { hour12: false })}
                      </span>
                      <span className={`shrink-0 flex items-center justify-center w-5 h-5 rounded-full bg-background border border-border mt-0.5
                        ${log.type === 'success' ? 'text-[#23a559]' : 
                          log.type === 'warning' ? 'text-[#faa61a]' : 
                          log.type === 'error' ? 'text-destructive' : 
                          log.type === 'command' ? 'text-primary' : 
                          'text-muted-foreground'}`}>
                        {log.type === 'success' ? <CheckCircle2 className="w-3 h-3" /> :
                         log.type === 'warning' ? <AlertCircle className="w-3 h-3" /> :
                         log.type === 'error' ? <AlertCircle className="w-3 h-3" /> :
                         log.type === 'command' ? <TerminalSquare className="w-3 h-3" /> :
                         <Info className="w-3 h-3" />}
                      </span>
                      <span className={`break-words ${
                        log.type === 'error' ? 'text-destructive font-medium' : 
                        log.type === 'warning' ? 'text-[#faa61a]' :
                        'text-foreground/90'
                      }`}>
                        {log.event}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Servers */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 px-1">
              <Server className="w-5 h-5 text-muted-foreground" />
              <h2 className="text-lg font-medium text-foreground">Top Servers</h2>
            </div>
            <div className="bg-card border border-card-border rounded-xl shadow-sm overflow-hidden h-[500px] flex flex-col">
              <div className="flex-1 overflow-y-auto">
                {stats.servers.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    No servers joined
                  </div>
                ) : (
                  <ul className="divide-y divide-border">
                    {stats.servers.map(server => (
                      <li key={server.id} className="p-4 hover:bg-white/5 transition-colors flex items-center justify-between group">
                        <div className="flex items-center gap-3 truncate pr-4">
                          <div className="w-10 h-10 rounded-[10px] bg-background border border-border flex items-center justify-center text-muted-foreground font-medium shrink-0 group-hover:border-primary/50 transition-colors">
                            {server.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="truncate">
                            <p className="text-sm font-medium text-foreground truncate">{server.name}</p>
                            <p className="text-xs text-muted-foreground font-mono mt-0.5 opacity-70">{server.id}</p>
                          </div>
                        </div>
                        <div className="shrink-0 text-right">
                          <Badge variant="secondary" className="font-mono bg-background hover:bg-background">
                            {server.memberCount.toLocaleString()}
                          </Badge>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
