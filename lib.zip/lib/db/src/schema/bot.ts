import { pgTable, text, integer, timestamp, boolean } from "drizzle-orm/pg-core";

export const botStatsTable = pgTable("bot_stats", {
  id: integer("id").primaryKey().default(1),
  botName: text("bot_name").notNull().default(""),
  botId: text("bot_id").notNull().default(""),
  latency: integer("latency").notNull().default(0),
  serverCount: integer("server_count").notNull().default(0),
  uptimeSeconds: integer("uptime_seconds").notNull().default(0),
  startedAt: text("started_at").notNull().default(""),
  online: boolean("online").notNull().default(false),
  lastHeartbeat: timestamp("last_heartbeat", { withTimezone: true }),
});

export const botServersTable = pgTable("bot_servers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  memberCount: integer("member_count").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const botLogsTable = pgTable("bot_logs", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  time: text("time").notNull(),
  event: text("event").notNull(),
  type: text("type").notNull().default("info"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
